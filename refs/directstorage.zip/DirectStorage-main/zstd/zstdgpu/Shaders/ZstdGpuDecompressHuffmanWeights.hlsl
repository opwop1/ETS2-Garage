/**
 * ZstdGpuDecompressHuffmanWeights.hlsl
 *
 * A compute shader that decompresses FSE-compressed Huffman Weights.
 * The shader maps one stream of FSE-compressed Huffman Weights to a single thread.
 *
 * Copyright (c) Microsoft. All rights reserved.
 * This code is licensed under the MIT License (MIT).
 * THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
 * ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
 * IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
 * PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
 *
 * Advanced Technology Group (ATG)
 * Author(s):   Pavel Martishevsky (pamartis@microsoft.com)
 */

#include "../zstdgpu_shaders.h"
#include "../srt_headers/ZstdGpuSrt_DecompressHuffmanWeights.h"

#ifdef __XBOX_SCARLETT
#define __XBOX_ENABLE_WAVE32 1
#endif

[RootSignature(ZSTDGPU_SRT_RS_DecompressHuffmanWeights)]
[numthreads(kzstdgpu_TgSizeX_DecompressHuffmanWeights, 1, 1)]
void main(uint2 groupId : SV_GroupID, uint32_t i : SV_GroupThreadId)
{
    zstdgpu_DecompressHuffmanWeights_SRT srt;

    zstdgpu_Srt_Fill(srt);

    i += zstdgpu_ConvertTo32BitGroupId(groupId, srt.tgOffset) * kzstdgpu_TgSizeX_DecompressHuffmanWeights;

    zstdgpu_ShaderEntry_DecompressHuffmanWeights(srt, i);
}
